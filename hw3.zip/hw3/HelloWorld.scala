/* Hello World Example */
object HelloWorld {
  def main () {
    // Print text to the console
    print ("Hello World")
  }
}

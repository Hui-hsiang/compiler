 //Without main method
object error1 {
	val a:boolean = true
	var b:int = 5
	def add(i:int,j:int):int{
	return i+j
	}
}
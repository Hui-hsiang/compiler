//if (express) type error
object error6 {
	def main (){
		var b = 7
		var k:string = "Hello"
		if (k){
			print("Error")
		}
		else print("Error")
	}
}
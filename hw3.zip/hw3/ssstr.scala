// string test

object ssstr{
  val a = 5 + 8
  val s = "String test"

  def main(){
    
    println(s)
  }
}
